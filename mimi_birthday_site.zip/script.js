function goToPage(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
  document.getElementById(pageId).classList.remove('hidden');
}

// Step 1 & 2 puzzle check
function checkPuzzle() {
  const word = document.getElementById("wordAnswer").value.trim().toLowerCase();
  const math = document.getElementById("mathAnswer").value.trim();
  const msg = document.getElementById("puzzleMsg");

  if (word === "mimi" && math === "2040") {
    msg.textContent = "✅ Correct! Now go unlock your treasure.";
    goToPage("unlock");
  } else {
    msg.textContent = "❌ Try again!";
  }
}

// Code unlock
function checkCode() {
  const code = document.getElementById("codeInput").value.trim();
  const msg = document.getElementById("codeMsg");

  if (code === "MIM-NL8kaxCVXN") {
    msg.textContent = "✅ Code accepted!";
    goToPage("treasure");
    startConfetti();
  } else {
    msg.textContent = "❌ Wrong code, try again!";
  }
}

// Confetti animation
function startConfetti() {
  const canvas = document.getElementById("confetti");
  const ctx = canvas.getContext("2d");
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;

  let pieces = [];
  for (let i = 0; i < 150; i++) {
    pieces.push({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height - canvas.height,
      w: 10,
      h: 10,
      color: `hsl(${Math.random() * 360}, 100%, 50%)`,
      speed: Math.random() * 3 + 2
    });
  }

  function update() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (let p of pieces) {
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x, p.y, p.w, p.h);
      p.y += p.speed;
      if (p.y > canvas.height) p.y = -10;
    }
    requestAnimationFrame(update);
  }
  update();
}